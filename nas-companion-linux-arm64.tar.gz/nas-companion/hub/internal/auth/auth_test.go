package auth

import (
	"net/http"
	"net/http/httptest"
	"testing"
)

// fakeAuth returns a canned result for the presented token.
func fakeAuth(valid map[string]bool) AuthFunc {
	return func(token string) bool { return valid[token] }
}

// TestRequireDevice verifies only valid non-revoked device tokens pass and
// there is no shared static token concept.
func TestRequireDevice(t *testing.T) {
	valid := map[string]bool{"device-token-1": true}
	mw := RequireDevice(fakeAuth(valid))
	handler := mw(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	}))

	cases := []struct {
		name string
		auth string
		want int
	}{
		{"no auth", "", http.StatusUnauthorized},
		{"malformed", "token-without-bearer", http.StatusUnauthorized},
		{"unknown token", "Bearer unknown-token", http.StatusUnauthorized},
		{"valid device token", "Bearer device-token-1", http.StatusOK},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			req := httptest.NewRequest(http.MethodGet, "/api/v1/services", nil)
			if c.auth != "" {
				req.Header.Set("Authorization", c.auth)
			}
			rec := httptest.NewRecorder()
			handler.ServeHTTP(rec, req)
			if rec.Code != c.want {
				t.Fatalf("code = %d, want %d", rec.Code, c.want)
			}
		})
	}
}

// TestRequireDeviceRevoked verifies a revoked token is 401 even though the
// token value itself is unchanged (revocation takes effect immediately).
func TestRequireDeviceRevoked(t *testing.T) {
	state := map[string]bool{"revoked-token": true}
	mw := RequireDevice(fakeAuth(state))
	handler := mw(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	}))

	ok := func(want int) {
		t.Helper()
		req := httptest.NewRequest(http.MethodGet, "/api/v1/services", nil)
		req.Header.Set("Authorization", "Bearer revoked-token")
		rec := httptest.NewRecorder()
		handler.ServeHTTP(rec, req)
		if rec.Code != want {
			t.Fatalf("code = %d, want %d", rec.Code, want)
		}
	}
	ok(http.StatusOK)
	state["revoked-token"] = false // revoke
	ok(http.StatusUnauthorized)
}

// TestBearerToken verifies extraction.
func TestBearerToken(t *testing.T) {
	if got := BearerToken("Bearer abc"); got != "abc" {
		t.Fatalf("got %q", got)
	}
	if got := BearerToken("abc"); got != "" {
		t.Fatalf("got %q", got)
	}
	if got := BearerToken(""); got != "" {
		t.Fatalf("got %q", got)
	}
}
