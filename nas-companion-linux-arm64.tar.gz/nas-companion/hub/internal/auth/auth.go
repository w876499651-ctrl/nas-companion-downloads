// Package auth provides the device-token authentication middleware for the
// V2 Hub. There is no shared static App token: each paired device
// authenticates with its own opaque device token via
//
//	Authorization: Bearer <device_token>
//
// Unknown, malformed or revoked credentials return 401.
package auth

import (
	"net/http"
	"strings"
)

// TokenAuthenticator validates a device token (including revocation).
type TokenAuthenticator interface {
	AuthenticateToken(token string) bool
}

// AuthFunc adapts a function to TokenAuthenticator.
type AuthFunc func(token string) bool

// AuthenticateToken implements TokenAuthenticator.
func (f AuthFunc) AuthenticateToken(token string) bool { return f(token) }

// RequireDevice returns middleware requiring a valid non-revoked per-device
// Bearer token. There is no shared static token in this model.
func RequireDevice(a TokenAuthenticator) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			token := BearerToken(r.Header.Get("Authorization"))
			if token == "" || !a.AuthenticateToken(token) {
				w.WriteHeader(http.StatusUnauthorized)
				_, _ = w.Write([]byte(`{"error":"unauthorized"}`))
				return
			}
			next.ServeHTTP(w, r)
		})
	}
}

// BearerToken extracts a Bearer token from an Authorization header.
func BearerToken(header string) string {
	const prefix = "Bearer "
	if !strings.HasPrefix(header, prefix) {
		return ""
	}
	return strings.TrimSpace(strings.TrimPrefix(header, prefix))
}
