package wiring

import (
	"encoding/json"
	"net"
	"net/http"
	"regexp"

	"github.com/nas-companion/nas/v2/hub/internal/identity"
	"github.com/nas-companion/nas/v2/hub/internal/pairing"
)

// pairCodeRe matches the frozen pairing_code pattern: 6-12 decimal digits.
var pairCodeRe = regexp.MustCompile(`^[0-9]{6,12}$`)

// clientIP extracts the client IP from the request (RemoteAddr host part).
// Used as the pairing rate-limit key so rotating different wrong codes from
// the same client still hits the per-source budget (review blocker 3).
func clientIP(r *http.Request) string {
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return host
}

// PairHandler implements POST /api/v1/pair per contracts/v2/hub-access.md
// §4 and the frozen request/response schemas. On success it consumes the
// one-time code and returns the device credential exactly once.
func PairHandler(pm *pairing.PairingManager, id *identity.Identity) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			w.WriteHeader(http.StatusMethodNotAllowed)
			return
		}
		var req struct {
			PairingCode string `json:"pairing_code"`
			DeviceName  string `json:"device_name"`
		}
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 8192)).Decode(&req); err != nil {
			http.Error(w, "invalid request body", http.StatusBadRequest)
			return
		}
		if !pairCodeRe.MatchString(req.PairingCode) {
			http.Error(w, "pairing_code must be 6-12 decimal digits", http.StatusBadRequest)
			return
		}
		if req.DeviceName == "" || len(req.DeviceName) > 64 {
			http.Error(w, "device_name must be 1-64 characters", http.StatusBadRequest)
			return
		}
		if err := pm.ConsumeCode(clientIP(r), req.PairingCode); err != nil {
			// Invalid/expired/used/rate-limited codes all fail authentication.
			w.WriteHeader(http.StatusUnauthorized)
			_, _ = w.Write([]byte(`{"error":"invalid or expired pairing code"}`))
			return
		}
		deviceID, token, err := pm.PairDevice(req.DeviceName)
		if err != nil {
			w.WriteHeader(http.StatusInternalServerError)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]string{
			"hub_id":       id.HubID(),
			"public_key":   id.PublicKeyB64(),
			"device_id":    deviceID,
			"device_token": token,
		})
	}
}
