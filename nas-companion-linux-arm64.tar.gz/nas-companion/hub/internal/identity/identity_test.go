package identity

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"regexp"
	"strings"
	"testing"
)

// TestIdentityPersistsAcrossRestart verifies the identity is stable across
// reloads (container restart, port/address change) (NAS_SCOPE §12/§14).
func TestIdentityPersistsAcrossRestart(t *testing.T) {
	path := filepath.Join(t.TempDir(), "hub", "identity.pem")
	a, err := LoadOrCreate(path)
	if err != nil {
		t.Fatal(err)
	}
	b, err := LoadOrCreate(path)
	if err != nil {
		t.Fatal(err)
	}
	if a.HubID() != b.HubID() {
		t.Fatalf("hub_id changed across reload: %s != %s", a.HubID(), b.HubID())
	}
}

// TestHubIDFormat verifies the frozen "sha256:" + 64 lowercase hex format.
func TestHubIDFormat(t *testing.T) {
	id, err := LoadOrCreate(filepath.Join(t.TempDir(), "identity.pem"))
	if err != nil {
		t.Fatal(err)
	}
	if !regexp.MustCompile(`^sha256:[0-9a-f]{64}$`).MatchString(id.HubID()) {
		t.Fatalf("hub_id format: %q", id.HubID())
	}
}

// TestSignVerifyProofRoundTrip verifies signature validity and tamper
// rejection (NAS_SCOPE §14: tamper rejection).
func TestSignVerifyProofRoundTrip(t *testing.T) {
	id, err := LoadOrCreate(filepath.Join(t.TempDir(), "identity.pem"))
	if err != nil {
		t.Fatal(err)
	}
	nonce := "0123456789abcdef0123456789abcdef"
	sig := id.SignProof(nonce)
	if err := VerifyProof(id.PublicKeyB64(), nonce, sig); err != nil {
		t.Fatalf("valid signature rejected: %v", err)
	}
	// Tampered nonce must fail.
	if err := VerifyProof(id.PublicKeyB64(), "tampered", sig); err == nil {
		t.Fatal("tampered nonce verified")
	}
	// Tampered signature must fail.
	if err := VerifyProof(id.PublicKeyB64(), nonce, "A"+sig[1:]); err == nil {
		t.Fatal("tampered signature verified")
	}
}

// TestVerifyHubID verifies hub_id == sha256 of the raw public key.
func TestVerifyHubID(t *testing.T) {
	id, err := LoadOrCreate(filepath.Join(t.TempDir(), "identity.pem"))
	if err != nil {
		t.Fatal(err)
	}
	if !VerifyHubID(id.HubID(), id.pub) {
		t.Fatal("hub_id must match SHA-256 of raw public key")
	}
	if VerifyHubID("sha256:0000000000000000000000000000000000000000000000000000000000000000", id.pub) {
		t.Fatal("wrong hub_id accepted")
	}
}

// TestChallengeEndpointSchema verifies the endpoint output matches
// hub-identity-proof.schema.json shape and that the signature covers the
// exact contract message (NAS_SCOPE §12).
func TestChallengeEndpointSchema(t *testing.T) {
	id, err := LoadOrCreate(filepath.Join(t.TempDir(), "identity.pem"))
	if err != nil {
		t.Fatal(err)
	}
	nonce := strings.Repeat("A", 22) // base64url no-padding, >=16 bytes
	body := `{"nonce":"` + nonce + `"}`
	req := httptest.NewRequest(http.MethodPost, "/api/v1/identity/challenge", strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	ChallengeHandler(id)(rec, req)

	if rec.Code != http.StatusOK {
		t.Fatalf("code = %d body=%s", rec.Code, rec.Body.String())
	}
	var out struct {
		HubID     string `json:"hub_id"`
		PublicKey string `json:"public_key"`
		Nonce     string `json:"nonce"`
		Signature string `json:"signature"`
	}
	if err := json.Unmarshal(rec.Body.Bytes(), &out); err != nil {
		t.Fatal(err)
	}
	if out.HubID != id.HubID() {
		t.Fatalf("hub_id mismatch")
	}
	if out.PublicKey != id.PublicKeyB64() {
		t.Fatalf("public_key mismatch")
	}
	if out.Nonce != nonce {
		t.Fatalf("nonce echo mismatch")
	}
	// Schema patterns:
	// hub_id ^sha256:[0-9a-f]{64}$ ; public_key ^[A-Za-z0-9_-]{43}$ ;
	// nonce ^[A-Za-z0-9_-]{22,128}$ ; signature ^[A-Za-z0-9_-]{86}$
	if !regexp.MustCompile(`^sha256:[0-9a-f]{64}$`).MatchString(out.HubID) {
		t.Fatalf("hub_id schema: %q", out.HubID)
	}
	if !regexp.MustCompile(`^[A-Za-z0-9_-]{43}$`).MatchString(out.PublicKey) {
		t.Fatalf("public_key schema: %q", out.PublicKey)
	}
	if !regexp.MustCompile(`^[A-Za-z0-9_-]{86}$`).MatchString(out.Signature) {
		t.Fatalf("signature schema: %q", out.Signature)
	}
	// The signature must verify over the exact contract message.
	if err := VerifyProof(out.PublicKey, out.Nonce, out.Signature); err != nil {
		t.Fatalf("endpoint signature invalid: %v", err)
	}
}

// TestChallengeEndpointRequiresNonce verifies missing/too-short nonce is
// rejected with 400 (contract requires >=16 random bytes).
func TestChallengeEndpointRequiresNonce(t *testing.T) {
	id, err := LoadOrCreate(filepath.Join(t.TempDir(), "identity.pem"))
	if err != nil {
		t.Fatal(err)
	}
	for _, body := range []string{`{}`, `{"nonce":""}`, `{"nonce":"short"}`} {
		req := httptest.NewRequest(http.MethodPost, "/api/v1/identity/challenge", strings.NewReader(body))
		req.Header.Set("Content-Type", "application/json")
		rec := httptest.NewRecorder()
		ChallengeHandler(id)(rec, req)
		if rec.Code != http.StatusBadRequest {
			t.Fatalf("body %s: code = %d, want 400", body, rec.Code)
		}
	}
}

// TestChallengeEndpointUnauthenticated verifies the endpoint requires no
// credential (by design, before device pairing).
func TestChallengeEndpointUnauthenticated(t *testing.T) {
	id, err := LoadOrCreate(filepath.Join(t.TempDir(), "identity.pem"))
	if err != nil {
		t.Fatal(err)
	}
	body := `{"nonce":"AAAAAAAAAAAAAAAAAAAAAA"}`
	req := httptest.NewRequest(http.MethodPost, "/api/v1/identity/challenge", strings.NewReader(body))
	rec := httptest.NewRecorder()
	ChallengeHandler(id)(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("identity challenge must be unauthenticated, got %d", rec.Code)
	}
}
