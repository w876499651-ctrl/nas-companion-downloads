// Package identity implements the stable Hub Ed25519 identity and the
// identity-proof endpoint frozen by contracts/v2/hub-access.md and
// hub-identity-proof.schema.json.
//
// The identity key pair is created once and persisted in the Hub
// application-data directory; it stays identical across Hub/NAS restarts,
// host-port changes, LAN/Public address changes and user-created reverse
// proxies. Deleting the key means a new Hub and requires re-pairing.
package identity

import (
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/pem"
	"errors"
	"fmt"
	"os"
	"path/filepath"
)

// SignPrefix is the exact UTF-8 prefix of the identity challenge message.
const SignPrefix = "nas-companion-v2:identity:"

// Identity is the persistent Hub identity.
type Identity struct {
	priv ed25519.PrivateKey
	pub  ed25519.PublicKey
}

// LoadOrCreate loads the identity from path, creating it if absent.
// The key file is written with 0600 permissions.
func LoadOrCreate(path string) (*Identity, error) {
	if b, err := os.ReadFile(path); err == nil {
		block, _ := pem.Decode(b)
		if block == nil || block.Type != "ED25519 PRIVATE KEY" {
			return nil, errors.New("invalid identity key file")
		}
		priv := ed25519.PrivateKey(block.Bytes)
		if len(priv) != ed25519.PrivateKeySize {
			return nil, errors.New("invalid ed25519 private key length")
		}
		return &Identity{priv: priv, pub: priv.Public().(ed25519.PublicKey)}, nil
	} else if !os.IsNotExist(err) {
		return nil, err
	}

	pub, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		return nil, err
	}
	id := &Identity{priv: priv, pub: pub}
	if err := id.save(path); err != nil {
		return nil, err
	}
	return id, nil
}

func (i *Identity) save(path string) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	block := &pem.Block{Type: "ED25519 PRIVATE KEY", Bytes: i.priv}
	b := pem.EncodeToMemory(block)
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, b, 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

// HubID returns the stable identity: "sha256:" + lowercase hex of the
// SHA-256 hash of the raw Ed25519 public key (contract §2).
func (i *Identity) HubID() string {
	sum := sha256.Sum256(i.pub)
	return "sha256:" + hex.EncodeToString(sum[:])
}

// PublicKeyB64 returns the raw 32-byte Ed25519 public key encoded as
// base64url without padding (hub-identity-proof.schema.json).
func (i *Identity) PublicKeyB64() string {
	return base64.RawURLEncoding.EncodeToString(i.pub)
}

// SignProof signs the caller nonce per the contract:
//
//	nas-companion-v2:identity:<nonce>
//
// The signature is 64 bytes encoded as base64url without padding.
func (i *Identity) SignProof(nonce string) string {
	msg := []byte(SignPrefix + nonce)
	return base64.RawURLEncoding.EncodeToString(ed25519.Sign(i.priv, msg))
}

// VerifyProof verifies a base64url signature over the contract message
// with the given base64url public key. It returns an error on any
// malformed input or failed verification.
func VerifyProof(pubB64, nonce, sigB64 string) error {
	pub, err := base64.RawURLEncoding.DecodeString(pubB64)
	if err != nil {
		return fmt.Errorf("decode public key: %w", err)
	}
	if len(pub) != ed25519.PublicKeySize {
		return errors.New("invalid public key length")
	}
	sig, err := base64.RawURLEncoding.DecodeString(sigB64)
	if err != nil {
		return fmt.Errorf("decode signature: %w", err)
	}
	if len(sig) != ed25519.SignatureSize {
		return errors.New("invalid signature length")
	}
	msg := []byte(SignPrefix + nonce)
	if !ed25519.Verify(pub, msg, sig) {
		return errors.New("signature verification failed")
	}
	return nil
}

// VerifyHubID checks that hubID equals sha256:hex(SHA-256(rawPub)).
func VerifyHubID(hubID string, pub ed25519.PublicKey) bool {
	sum := sha256.Sum256(pub)
	return hubID == "sha256:"+hex.EncodeToString(sum[:])
}
