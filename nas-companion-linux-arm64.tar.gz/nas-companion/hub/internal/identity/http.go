package identity

import (
	"encoding/base64"
	"encoding/json"
	"errors"
	"net/http"
	"strings"
)

// minNonceBytes is the contract floor: the nonce must contain at least 16
// random bytes.
const minNonceBytes = 16

// ChallengeHandler implements POST /api/v1/identity/challenge
// (contract §3, frozen response by hub-identity-proof.schema.json).
// It is unauthenticated by design: it lets a client confirm it talks to
// the same Hub (across LAN and Public endpoints) before sending any device
// credential.
func ChallengeHandler(id *Identity) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			w.WriteHeader(http.StatusMethodNotAllowed)
			return
		}
		var req struct {
			Nonce string `json:"nonce"`
		}
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 4096)).Decode(&req); err != nil {
			http.Error(w, "invalid request body", http.StatusBadRequest)
			return
		}
		nonceBytes, err := base64.RawURLEncoding.DecodeString(req.Nonce)
		if err != nil || len(nonceBytes) < minNonceBytes {
			http.Error(w, "nonce must be base64url of at least 16 random bytes", http.StatusBadRequest)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]string{
			"hub_id":     id.HubID(),
			"public_key": id.PublicKeyB64(),
			"nonce":      req.Nonce,
			"signature":  id.SignProof(req.Nonce),
		})
	}
}

// ErrInvalidNonce is returned when the nonce is malformed or too short.
var ErrInvalidNonce = errors.New("invalid nonce")

var _ = strings.TrimSpace
