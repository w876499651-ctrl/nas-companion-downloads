// Package config loads Hub runtime configuration from the environment.
// There is deliberately no shared static App token: authentication is
// per-device after pairing (contracts/v2/hub-access.md). The Hub identity
// and device store persist under DataDir.
package config

import (
	"errors"
	"os"
)

// Config holds Hub runtime settings.
type Config struct {
	Listen  string
	DataDir string
}

// Load reads configuration from environment variables with safe defaults.
func Load() Config {
	return Config{
		Listen:  getenv("HUB_LISTEN", "0.0.0.0:8080"),
		DataDir: getenv("HUB_DATA_DIR", "/data"),
	}
}

// Validate checks required fields.
func (c Config) Validate() error {
	if c.Listen == "" {
		return errors.New("HUB_LISTEN must not be empty")
	}
	if c.DataDir == "" {
		return errors.New("HUB_DATA_DIR must not be empty")
	}
	return nil
}

func getenv(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}
