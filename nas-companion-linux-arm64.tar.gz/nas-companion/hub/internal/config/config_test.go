// Package config loads Hub runtime configuration from environment.
package config

import (
	"os"
	"path/filepath"
	"testing"
)

// TestConfigDefaults verifies sane defaults when env vars are absent.
func TestConfigDefaults(t *testing.T) {
	for _, k := range []string{"HUB_LISTEN", "HUB_DATA_DIR"} {
		_ = os.Unsetenv(k)
	}
	c := Load()
	if c.Listen == "" {
		t.Fatal("listen must default to a value")
	}
	if c.DataDir == "" {
		t.Fatal("data dir must default to a value")
	}
}

// TestConfigFromEnv verifies env values are picked up.
func TestConfigFromEnv(t *testing.T) {
	dir := filepath.Join(t.TempDir(), "hubdata")
	os.Setenv("HUB_LISTEN", "127.0.0.1:9999")
	os.Setenv("HUB_DATA_DIR", dir)
	defer func() {
		_ = os.Unsetenv("HUB_LISTEN")
		_ = os.Unsetenv("HUB_DATA_DIR")
	}()
	c := Load()
	if c.Listen != "127.0.0.1:9999" || c.DataDir != dir {
		t.Fatalf("config = %+v", c)
	}
}

// TestConfigNoStaticToken verifies the config has no shared static App
// token fields (contract §4: there is no shared static App token).
func TestConfigNoStaticToken(t *testing.T) {
	c := Config{Listen: ":8080", DataDir: t.TempDir()}
	if err := c.Validate(); err != nil {
		t.Fatalf("validate: %v", err)
	}
}
