package pairing

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"testing"
	"time"
)

func newTestManager(t *testing.T) *PairingManager {
	t.Helper()
	m, err := NewPairingManager(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	return m
}

// TestCodeIsDecimal6To12 verifies the human pairing code format
// (contract §4: 6-12 decimal digits).
func TestCodeIsDecimal6To12(t *testing.T) {
	m := newTestManager(t)
	for i := 0; i < 30; i++ {
		code, err := m.IssueCode()
		if err != nil {
			t.Fatal(err)
		}
		if !regexp.MustCompile(`^[0-9]{6,12}$`).MatchString(code) {
			t.Fatalf("code %q is not 6-12 decimal digits", code)
		}
	}
}

// TestCodeSingleUse verifies a consumed code cannot be reused
// (contract §4: succeeds at most once).
func TestCodeSingleUse(t *testing.T) {
	m := newTestManager(t)
	code, err := m.IssueCode()
	if err != nil {
		t.Fatal(err)
	}
	if err := m.ConsumeCode("", code); err != nil {
		t.Fatalf("first consume: %v", err)
	}
	if err := m.ConsumeCode("", code); err == nil {
		t.Fatal("code must be single-use")
	}
}

// TestCodeExpiry verifies an expired code is rejected (contract §4).
func TestCodeExpiry(t *testing.T) {
	m := newTestManager(t)
	m.now = func() time.Time { return time.Unix(1_700_000_000, 0) }
	code, err := m.IssueCode()
	if err != nil {
		t.Fatal(err)
	}
	m.now = func() time.Time { return time.Unix(1_700_000_000, 0).Add(CodeTTL + time.Second) }
	if err := m.ConsumeCode("", code); err == nil {
		t.Fatal("expired code must be rejected")
	}
}

// TestRateLimit verifies repeated invalid attempts are rate-limited
// (contract §4: repeated invalid attempts must be rate-limited).
func TestRateLimit(t *testing.T) {
	m := newTestManager(t)
	code, err := m.IssueCode()
	if err != nil {
		t.Fatal(err)
	}
	// Consume the real code first so "wrong" codes dominate.
	_ = m.ConsumeCode("", code)
	for i := 0; i < maxPairAttempts; i++ {
		if err := m.ConsumeCode("", "000000"); err == nil {
			t.Fatalf("invalid code accepted at attempt %d", i)
		}
	}
	// The 6th invalid attempt must be rate-limited.
	if err := m.ConsumeCode("", "000000"); err != errRateLimited {
		t.Fatalf("expected rate limit, got %v", err)
	}
}

// TestRateLimitRotatingCodes verifies different invalid code values are
// counted independently: hammering one code must not rate-limit another.
func TestRateLimitRotatingCodes(t *testing.T) {
	m := newTestManager(t)
	for i := 0; i < maxPairAttempts; i++ {
		if err := m.ConsumeCode("", "111111"); err == nil {
			t.Fatalf("invalid code accepted at attempt %d", i)
		}
	}
	// 111111 is now rate-limited.
	if err := m.ConsumeCode("", "111111"); err != errRateLimited {
		t.Fatalf("expected 111111 rate-limited, got %v", err)
	}
	// A different invalid code is unaffected (own counter).
	if err := m.ConsumeCode("", "222222"); err != errInvalidCode {
		t.Fatalf("222222 must still return invalid (not rate-limited), got %v", err)
	}
}

// TestRateLimitRotatingCodesSameSourceBlocked verifies that rotating through
// DIFFERENT wrong pairing codes from the SAME source still hits the
// per-source budget and is rate-limited (review blocker 3: counting only by
// the guessed code string is bypassable by rotating codes).
func TestRateLimitRotatingCodesSameSourceBlocked(t *testing.T) {
	m := newTestManager(t)
	const src = "10.0.0.7"
	for i := 0; i < maxPairAttempts; i++ {
		// Each attempt uses a different wrong code value.
		code := fmt.Sprintf("%06d", i+1)
		if err := m.ConsumeCode(src, code); err == nil {
			t.Fatalf("invalid code accepted at attempt %d", i)
		}
	}
	// The 6th attempt with yet another fresh wrong code must be
	// rate-limited because the SOURCE budget is exhausted.
	if err := m.ConsumeCode(src, "999999"); err != errRateLimited {
		t.Fatalf("same-source rotating codes must be rate-limited, got %v", err)
	}
	// A different source is not affected by this source's budget.
	if err := m.ConsumeCode("10.0.0.9", "999999"); err != errInvalidCode {
		t.Fatalf("other source must not be rate-limited, got %v", err)
	}
}

// TestRateLimitWindowRecovery verifies the rate limit resets once the
// window elapses: the same code value is again rejected as invalid (not
// rate-limited) and a later valid code can pair.
func TestRateLimitWindowRecovery(t *testing.T) {
	m := newTestManager(t)
	// Freeze time so the window does not silently elapse during setup.
	m.now = func() time.Time { return time.Unix(1_700_000_000, 0) }
	for i := 0; i < maxPairAttempts; i++ {
		_ = m.ConsumeCode("", "555555") // wrong value
	}
	if err := m.ConsumeCode("", "555555"); err != errRateLimited {
		t.Fatalf("expected rate-limited, got %v", err)
	}
	// Window elapsed -> the code is usable again.
	m.now = func() time.Time { return time.Unix(1_700_000_000, 0).Add(rateLimitWindow + time.Second) }
	if err := m.ConsumeCode("", "555555"); err != errInvalidCode {
		t.Fatalf("after window, expected invalid (not rate-limited), got %v", err)
	}
	// And a freshly issued code still pairs fine after recovery.
	fresh, err := m.IssueCode()
	if err != nil {
		t.Fatal(err)
	}
	if err := m.ConsumeCode("", fresh); err != nil {
		t.Fatalf("fresh code must pair after window recovery: %v", err)
	}
}

// TestRateLimitWindowIsOpenRejects verifies the window state is actually
// enforced over time: reaching the threshold mid-window keeps the code
// locked, and the lock is real (not just a counter reset on each call).
func TestRateLimitWindowIsOpenRejects(t *testing.T) {
	m := newTestManager(t)
	m.now = func() time.Time { return time.Unix(1_700_000_000, 0) }
	for i := 0; i < maxPairAttempts; i++ {
		_ = m.ConsumeCode("", "999999")
	}
	// Halfway through the window the code stays locked.
	m.now = func() time.Time { return time.Unix(1_700_000_000, 0).Add(rateLimitWindow / 2) }
	if err := m.ConsumeCode("", "999999"); err != errRateLimited {
		t.Fatalf("code must stay rate-limited mid-window, got %v", err)
	}
}

// TestPerDeviceCredentials verifies each device gets a unique id + token
// (contract §4/§5).
func TestPerDeviceCredentials(t *testing.T) {
	m := newTestManager(t)
	idA, tokA, err := m.PairDevice("phone-a")
	if err != nil {
		t.Fatal(err)
	}
	idB, tokB, err := m.PairDevice("phone-b")
	if err != nil {
		t.Fatal(err)
	}
	if idA == idB || tokA == tokB {
		t.Fatal("devices must not share credentials")
	}
	// UUID format for device_id (hub-pair-response.schema.json).
	if !regexp.MustCompile(`^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$`).MatchString(idA) {
		t.Fatalf("device_id must be a UUID: %q", idA)
	}
	// device_token: >= 256 bits randomness => 32 bytes => 43 base64url chars.
	if len(tokA) < 43 {
		t.Fatalf("device_token too short: %d chars", len(tokA))
	}
}

// TestOnlyVerifierPersisted verifies the Hub never stores the plaintext
// token (contract §4: persist only a non-reversible verifier/hash).
func TestOnlyVerifierPersisted(t *testing.T) {
	dir := t.TempDir()
	m, err := NewPairingManager(dir)
	if err != nil {
		t.Fatal(err)
	}
	_, tok, err := m.PairDevice("phone")
	if err != nil {
		t.Fatal(err)
	}
	b, err := os.ReadFile(filepath.Join(dir, "pairing-state.json"))
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(b), tok) {
		t.Fatal("plaintext device token persisted in state file")
	}
	// Devices() never exposes verifiers.
	for _, d := range m.Devices() {
		raw, _ := json.Marshal(d)
		if strings.Contains(string(raw), "verifier") {
			t.Fatalf("Devices() exposes verifier: %s", raw)
		}
	}
}

// TestAuthenticateToken verifies a valid token authenticates and revoked
// devices immediately fail (contract §5/§6).
func TestAuthenticateToken(t *testing.T) {
	m := newTestManager(t)
	id, tok, err := m.PairDevice("phone")
	if err != nil {
		t.Fatal(err)
	}
	if !m.AuthenticateToken(tok) {
		t.Fatal("valid token must authenticate")
	}
	if m.AuthenticateToken("wrong-token") {
		t.Fatal("invalid token must not authenticate")
	}
	if err := m.RevokeDevice(id); err != nil {
		t.Fatal(err)
	}
	if m.AuthenticateToken(tok) {
		t.Fatal("revoked device must not authenticate")
	}
	// Other devices remain valid.
	_, tok2, err := m.PairDevice("other")
	if err != nil {
		t.Fatal(err)
	}
	if !m.AuthenticateToken(tok2) {
		t.Fatal("unaffected device must still authenticate")
	}
}

// TestStateSurvivesRestart verifies devices survive a Hub restart.
func TestStateSurvivesRestart(t *testing.T) {
	dir := t.TempDir()
	m, err := NewPairingManager(dir)
	if err != nil {
		t.Fatal(err)
	}
	_, tok, err := m.PairDevice("phone")
	if err != nil {
		t.Fatal(err)
	}
	m2, err := NewPairingManager(dir)
	if err != nil {
		t.Fatal(err)
	}
	if !m2.AuthenticateToken(tok) {
		t.Fatal("device credential lost across restart")
	}
}

// TestDeviceNameBoundaries verifies device_name constraints (1-64).
func TestDeviceNameBoundaries(t *testing.T) {
	m := newTestManager(t)
	if _, _, err := m.PairDevice(""); err == nil {
		t.Fatal("empty device_name must be rejected")
	}
	if _, _, err := m.PairDevice(strings.Repeat("x", 65)); err == nil {
		t.Fatal("overlong device_name must be rejected")
	}
}

// TestRevokeUnknownDevice verifies revoking a missing device errors.
func TestRevokeUnknownDevice(t *testing.T) {
	m := newTestManager(t)
	if err := m.RevokeDevice("00000000-0000-0000-0000-000000000000"); err == nil {
		t.Fatal("revoking unknown device must fail")
	}
}
