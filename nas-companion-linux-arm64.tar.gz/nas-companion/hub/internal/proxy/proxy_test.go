package proxy

import (
	"bytes"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

// upstream is a configurable fake upstream service.
type upstream struct {
	lastPath     string
	lastQuery    string
	lastMethod   string
	lastBody     string
	gotHeader    http.Header
	responses    map[string]*http.Response
}

func (u *upstream) handler() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		u.lastPath = r.URL.Path
		u.lastQuery = r.URL.RawQuery
		u.lastMethod = r.Method
		u.gotHeader = r.Header.Clone()
		if r.Body != nil {
			b, _ := io.ReadAll(r.Body)
			u.lastBody = string(b)
		}
		switch r.Method {
		case http.MethodDelete:
			w.WriteHeader(http.StatusNoContent)
			return
		default:
			w.Header().Set("X-Upstream", "yes")
			w.WriteHeader(http.StatusOK)
			_, _ = w.Write([]byte("resp-" + r.URL.Path))
		}
	})
}

func newProxyTest(t *testing.T) (*Proxy, *upstream) {
	t.Helper()
	up := &upstream{}
	upSrv := httptest.NewServer(up.handler())
	t.Cleanup(upSrv.Close)

	p := &Proxy{
		Targets: map[string]string{
			"qbittorrent": upSrv.URL,
			"jackett":     upSrv.URL,
		},
	}
	return p, up
}

func do(t *testing.T, p *Proxy, method, target string, body io.Reader, hdr map[string]string) *httptest.ResponseRecorder {
	t.Helper()
	req := httptest.NewRequest(method, target, body)
	for k, v := range hdr {
		req.Header.Set(k, v)
	}
	rec := httptest.NewRecorder()
	p.ServeHTTP(rec, req)
	return rec
}

// TestProxyGET verifies GET forwarding with query passthrough.
func TestProxyGET(t *testing.T) {
	p, up := newProxyTest(t)
	rec := do(t, p, http.MethodGet, "/proxy/qbittorrent/api/v2/app/version?x=1", nil, nil)
	if rec.Code != http.StatusOK {
		t.Fatalf("code = %d", rec.Code)
	}
	if up.lastPath != "/api/v2/app/version" || up.lastQuery != "x=1" {
		t.Fatalf("upstream got path=%q query=%q", up.lastPath, up.lastQuery)
	}
	if rec.Body.String() != "resp-/api/v2/app/version" {
		t.Fatalf("body = %q", rec.Body.String())
	}
}

// TestProxyMethods verifies HEAD/POST/PUT/PATCH/DELETE forwarding
// (TEST_PLAN J).
func TestProxyMethods(t *testing.T) {
	p, up := newProxyTest(t)
	for _, m := range []string{http.MethodHead, http.MethodPost, http.MethodPut, http.MethodPatch, http.MethodDelete} {
		rec := do(t, p, m, "/proxy/jackett/anything", bytes.NewBufferString("hello"), nil)
		if rec.Code != http.StatusOK && rec.Code != http.StatusNoContent {
			t.Fatalf("%s code = %d", m, rec.Code)
		}
		if up.lastMethod != m {
			t.Fatalf("method = %q, want %q", up.lastMethod, m)
		}
		if m == http.MethodPost || m == http.MethodPut || m == http.MethodPatch {
			if up.lastBody != "hello" {
				t.Fatalf("%s body = %q", m, up.lastBody)
			}
		}
	}
}

// TestProxyStripsHubAuthHeader verifies the App-side Hub Authorization is
// not leaked upstream (TEST_PLAN J).
func TestProxyStripsHubAuthHeader(t *testing.T) {
	p, up := newProxyTest(t)
	rec := do(t, p, http.MethodGet, "/proxy/qbittorrent/x", nil, map[string]string{
		"Authorization": "Bearer hub-token",
	})
	if rec.Code != http.StatusOK {
		t.Fatalf("code = %d", rec.Code)
	}
	if got := up.gotHeader.Get("Authorization"); got != "" {
		t.Fatalf("hub auth leaked upstream: %q", got)
	}
}

// TestProxyStripsHopByHop verifies hop-by-hop headers are removed
// (TEST_PLAN J).
func TestProxyStripsHopByHop(t *testing.T) {
	p, up := newProxyTest(t)
	rec := do(t, p, http.MethodGet, "/proxy/qbittorrent/x", nil, map[string]string{
		"Connection": "keep-alive",
		"Keep-Alive": "timeout=5",
	})
	if rec.Code != http.StatusOK {
		t.Fatalf("code = %d", rec.Code)
	}
	if got := up.gotHeader.Get("Connection"); got != "" {
		t.Fatalf("Connection header leaked: %q", got)
	}
	if got := up.gotHeader.Get("Keep-Alive"); got != "" {
		t.Fatalf("Keep-Alive header leaked: %q", got)
	}
}

// TestProxyUnknownServiceRejected verifies unknown service ids are rejected
// (TEST_PLAN J).
func TestProxyUnknownServiceRejected(t *testing.T) {
	p, _ := newProxyTest(t)
	rec := do(t, p, http.MethodGet, "/proxy/evil/x", nil, nil)
	if rec.Code != http.StatusNotFound {
		t.Fatalf("code = %d", rec.Code)
	}
}

// TestProxyArbitraryURLRejected verifies no arbitrary upstream URL is
// accepted (TEST_PLAN C/J).
func TestProxyArbitraryURLRejected(t *testing.T) {
	p, _ := newProxyTest(t)
	for _, target := range []string{
		"/proxy/qbittorrent/?url=http://evil.example",
		"/proxy/qbittorrent/?url=https://evil.example/x",
		"/api/v1/services?url=http://evil.example",
	} {
		rec := do(t, p, http.MethodGet, target, nil, nil)
		if rec.Code == http.StatusOK {
			t.Fatalf("arbitrary URL accepted: %s", target)
		}
	}
}

// TestProxyResponseHeaders verifies upstream response headers pass through.
func TestProxyResponseHeaders(t *testing.T) {
	p, _ := newProxyTest(t)
	rec := do(t, p, http.MethodGet, "/proxy/qbittorrent/x", nil, nil)
	if rec.Header().Get("X-Upstream") != "yes" {
		t.Fatalf("upstream header lost: %+v", rec.Header())
	}
}

// TestProxyStreamsLargeBody verifies large responses stream without
// buffering into memory (TEST_PLAN J).
func TestProxyStreamsLargeBody(t *testing.T) {
	big := strings.Repeat("x", 8<<20) // 8 MiB
	upSrv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(big))
	}))
	defer upSrv.Close()
	p := &Proxy{Targets: map[string]string{"qbittorrent": upSrv.URL}}
	rec := do(t, p, http.MethodGet, "/proxy/qbittorrent/big", nil, nil)
	if rec.Body.Len() != len(big) {
		t.Fatalf("body size = %d, want %d", rec.Body.Len(), len(big))
	}
}
