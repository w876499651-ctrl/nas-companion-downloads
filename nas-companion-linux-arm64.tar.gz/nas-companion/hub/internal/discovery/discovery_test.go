package discovery

import (
	"encoding/json"
	"os"
	"testing"
)

// TestDiscoveryReadsRegistry verifies GET /api/v1/services payload shape.
func TestDiscoveryReadsRegistry(t *testing.T) {
	dir := t.TempDir()
	path := dir + "/registry.json"
	body := `{"services":[{"id":"qbittorrent","installed":true,"healthy":true}]}`
	if err := os.WriteFile(path, []byte(body), 0o600); err != nil {
		t.Fatal(err)
	}
	svcs, err := ReadRegistry(path)
	if err != nil {
		t.Fatal(err)
	}
	if len(svcs) != 1 || svcs[0].ID != "qbittorrent" || !svcs[0].Installed || !svcs[0].Healthy {
		t.Fatalf("unexpected services: %+v", svcs)
	}
}

// TestDiscoveryMissingRegistryEmpty verifies a missing registry yields an
// empty (but valid) service list.
func TestDiscoveryMissingRegistryEmpty(t *testing.T) {
	svcs, err := ReadRegistry(t.TempDir() + "/nope.json")
	if err != nil {
		t.Fatal(err)
	}
	if len(svcs) != 0 {
		t.Fatalf("expected empty list, got %+v", svcs)
	}
}

// TestDiscoveryJSONShape verifies the wire format only contains
// id/installed/healthy (TEST_PLAN C).
func TestDiscoveryJSONShape(t *testing.T) {
	list := []Service{
		{ID: "jackett", Installed: true, Healthy: false},
	}
	raw, err := json.Marshal(map[string]any{"services": list})
	if err != nil {
		t.Fatal(err)
	}
	lower := string(raw)
	for _, forbidden := range []string{"username", "password", "apikey", "cookie", "token", "secret", "hostPort"} {
		if contains(lower, forbidden) {
			t.Fatalf("discovery payload leaks %q: %s", forbidden, lower)
		}
	}
}

func contains(s, sub string) bool {
	return len(s) >= len(sub) && (indexOf(s, sub) >= 0)
}

func indexOf(s, sub string) int {
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub {
			return i
		}
	}
	return -1
}
