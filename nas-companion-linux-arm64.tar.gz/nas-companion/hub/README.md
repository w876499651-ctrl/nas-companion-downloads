# V2 Hub (nas/hub)

Thin authenticated gateway for Nas Companion V2，实现冻结契约
`contracts/v2/hub-access.md` 及三个 Hub schema（identity-proof / pair-request /
pair-response）。

## 职责

1. 稳定 Hub identity 证明：`POST /api/v1/identity/challenge`（免认证，Ed25519
   签名 `nas-companion-v2:identity:<nonce>`）
2. 一次性设备配对：`POST /api/v1/pair`（6-12 位十进制短时单次 code + 每设备
   独立 device_id/device_token）
3. 每设备认证：`Authorization: Bearer <device_token>`（仅存 verifier/hash，
   单设备可独立撤销，撤销后立即 401）
4. 服务发现：`GET /api/v1/services`（只含 id/installed/healthy）
5. Allow-list 反向代理：`/proxy/{service}/*`（仅 6 个冻结 service id）

**没有共享静态 App token。**

## 结构

```text
cmd/hub/            入口（HUB_LISTEN / HUB_DATA_DIR）
Dockerfile          本地构建（installer 用，绝不拉取预发布 Hub 镜像）
internal/config/    环境变量配置
internal/identity/  Ed25519 身份 + challenge 证明
internal/pairing/   一次性 code + 每设备凭证（verifier-only）+ 撤销
internal/auth/      Bearer device_token 认证中间件
internal/discovery/ 服务发现（读 installer 无凭据 registry）
internal/proxy/     allow-list 反向代理
internal/wiring/    路由组装
```

## 契约要点

- Hub identity 持久化于数据目录，重启/换端口/换地址不变；删除身份文件=新 Hub。
- pairing code：6-12 位十进制、≤10 分钟过期、单次成功、错误尝试限速。
- device_token ≥256 bit；Hub 只保存 SHA-256 verifier，明文仅配对时返回一次。
- 设备撤销立即生效（后续请求 401），不影响其他设备。
- Hub 消费 `Authorization` 头，绝不上游转发（proxy 剥离测试覆盖）。
- LAN/Public 双地址使用同一 identity proof 契约。

## 代理约束

- 只允许 `qbittorrent / jackett / cloudlink / anirss / xunlei / suwayomi`。
- 拒绝未知 service id；拒绝 `?url=` / 任意 upstream URL / SSRF 风格代理。
- 剥离 App 侧 Hub 认证头与 hop-by-hop headers。
- 支持 GET/HEAD/POST/PUT/PATCH/DELETE；query/body/status/响应头透传。
- 大文件/图片流式转发，不缓冲到内存。
- WebSocket 仅在确认有明确、已测试的真实业务需求后才实现（当前未实现）。

Hub 不管理 Docker 生命周期，不碰 Docker socket，不需要 privileged / host
network / NET_ADMIN，不实现重复业务 API。
