// Command hub is the thin Nas Companion V2 Hub per contracts/v2/hub-access.md:
// stable Ed25519 identity proof, one-time pairing, per-device device-token
// authentication with independent revocation, GET /api/v1/services and
// allow-listed reverse proxying. There is no shared static App token.
//
// It also provides local administration subcommands used by the NAS
// Installer (Foundation §6 / hub-access.md §6):
//
//	hub                        # run the Hub server
//	hub admin issue-code       # generate a one-time pairing code
//	hub admin list-devices     # list paired devices (non-secret)
//	hub admin revoke-device <id>
package main

import (
	"fmt"
	"log"
	"net/http"
	"os"

	"github.com/nas-companion/nas/v2/hub/internal/config"
	"github.com/nas-companion/nas/v2/hub/internal/pairing"
	"github.com/nas-companion/nas/v2/hub/internal/wiring"
)

func main() {
	if len(os.Args) > 1 && os.Args[1] == "admin" {
		if err := runAdmin(os.Args[2:]); err != nil {
			log.Fatalf("hub admin: %v", err)
		}
		return
	}
	runServer()
}

func runServer() {
	cfg := config.Load()
	if err := cfg.Validate(); err != nil {
		log.Fatalf("hub config: %v", err)
	}
	handler := wiring.Build(wiring.Options{
		DataDir:        cfg.DataDir,
		RegistryPath:   cfg.DataDir + "/registry.json",
		ServiceTargets: wiring.DefaultTargets(),
	})
	log.Printf("hub listening on %s", cfg.Listen)
	if err := http.ListenAndServe(cfg.Listen, handler); err != nil {
		log.Fatal(err)
	}
}

// runAdmin implements the local device-management subcommands. The pairing
// state lives in the Hub application-data directory, so the data dir must
// be the same one the Hub container uses (e.g. /data).
func runAdmin(args []string) error {
	if len(args) < 1 {
		return fmt.Errorf("usage: hub admin <issue-code|list-devices|revoke-device> [device-id]")
	}
	cmd := args[0]
	dataDir := ""
	rest := args[1:]
	for i := 0; i < len(rest); i++ {
		if rest[i] == "--data-dir" && i+1 < len(rest) {
			dataDir = rest[i+1]
			i++
		}
	}
	if dataDir == "" {
		dataDir = os.Getenv("HUB_DATA_DIR")
	}
	if dataDir == "" {
		return fmt.Errorf("data dir not provided (use --data-dir or HUB_DATA_DIR)")
	}
	pm, err := pairing.NewPairingManager(dataDir)
	if err != nil {
		return err
	}
	switch cmd {
	case "issue-code":
		code, err := pm.IssueCode()
		if err != nil {
			return err
		}
		fmt.Println(code)
		return nil
	case "list-devices":
		// Output: <id>\t<state>\t<name>. Name is LAST so names containing
		// spaces/tabs never shift the state column (review blocker 7).
		for _, d := range pm.Devices() {
			state := "active"
			if d.Revoked {
				state = "revoked"
			}
			fmt.Printf("%s\t%s\t%s\n", d.ID, state, d.Name)
		}
		return nil
	case "revoke-device":
		if len(rest) < 1 {
			return fmt.Errorf("usage: hub admin revoke-device --data-dir <dir> <device-id>")
		}
		// The device id is the first non-flag argument after the command.
		id := ""
		for _, a := range rest {
			if a != "--data-dir" && a != dataDir && dataDir == "" {
				continue
			}
			if a != "--data-dir" && a != dataDir && id == "" {
				id = a
			}
		}
		// Simpler and unambiguous: take the last non-flag token as the id.
		for i := len(rest) - 1; i >= 0; i-- {
			if rest[i] != "--data-dir" && rest[i] != dataDir {
				id = rest[i]
				break
			}
		}
		if id == "" {
			return fmt.Errorf("usage: hub admin revoke-device --data-dir <dir> <device-id>")
		}
		if err := pm.RevokeDevice(id); err != nil {
			return err
		}
		fmt.Printf("revoked %s\n", id)
		return nil
	default:
		return fmt.Errorf("unknown admin command %q", cmd)
	}
}
