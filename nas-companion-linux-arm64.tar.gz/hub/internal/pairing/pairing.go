// Package pairing implements the frozen V2 device pairing model
// (contracts/v2/hub-access.md, hub-pair-request.schema.json,
// hub-pair-response.schema.json).
//
// - one-time human pairing codes: decimal 6-12 digits, generated from
//   cryptographically secure randomness, expire <= 10 minutes, succeed at
//   most once, invalid attempts rate-limited;
// - each successful pairing creates an independent device record with a
//   unique UUID device_id and an opaque device_token containing >= 256 bits
//   of randomness;
// - the Hub persists only a non-reversible verifier/hash of the plaintext
//   device token (SHA-256), never the plaintext;
// - devices can be revoked independently; revoked devices return 401.
package pairing

import (
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"time"

	"github.com/google/uuid"
)

// CodeTTL is the pairing-code lifetime (contract: no later than 10 min).
const CodeTTL = 10 * time.Minute

// CodeMinDigits / CodeMaxDigits per contract (6 to 12 digits).
const (
	CodeMinDigits = 6
	CodeMaxDigits = 12
)

// maxPairAttempts is the rate-limit threshold for invalid pairing codes.
const maxPairAttempts = 5

// rateLimitWindow is the window in which repeated invalid attempts are
// counted before the Hub rejects further attempts.
const rateLimitWindow = 10 * time.Minute

// tokenBytes is the device-token entropy floor: >= 256 bits = 32 bytes.
const tokenBytes = 32

// Device is one paired client (public, non-secret shape).
type Device struct {
	ID        string    `json:"device_id"`
	Name      string    `json:"device_name"`
	CreatedAt time.Time `json:"created_at"`
	Revoked   bool      `json:"revoked"`
}

// deviceRecord is the persisted form: verifier only, never plaintext.
type deviceRecord struct {
	Name      string    `json:"name"`
	Verifier  string    `json:"verifier"` // sha256 hex of the device token
	CreatedAt time.Time `json:"created_at"`
	Revoked   bool      `json:"revoked"`
}

// codeRecord tracks one issued pairing code.
type codeRecord struct {
	ExpiresAt time.Time `json:"expires_at"`
}

// attemptRecord tracks invalid pairing-code attempts for one code value
// within the current rate-limit window.
type attemptRecord struct {
	Count      int       `json:"count"`
	WindowFrom time.Time `json:"window_from"` // when this window started
}

// PairingManager issues one-time codes, creates devices and verifies
// per-device tokens. State persists so restarts do not invalidate devices.
type PairingManager struct {
	mu            sync.Mutex
	path          string
	now           func() time.Time
	rand          func([]byte) (int, error)
	codes         map[string]codeRecord
	attempt       map[string]attemptRecord // pairing code -> rate-limit window state
	attemptSource map[string]attemptRecord // request source (client IP) -> rate-limit state
	devices       map[string]deviceRecord
}

// NewPairingManager loads pairing state from dir (or starts empty).
func NewPairingManager(dir string) (*PairingManager, error) {
	m := &PairingManager{
		path:          filepath.Join(dir, "pairing-state.json"),
		now:           time.Now,
		rand:          rand.Read,
		codes:         map[string]codeRecord{},
		attempt:       map[string]attemptRecord{},
		attemptSource: map[string]attemptRecord{},
		devices:       map[string]deviceRecord{},
	}
	if b, err := os.ReadFile(m.path); err == nil {
		if err := m.applyState(b); err != nil {
			return nil, err
		}
	} else if !os.IsNotExist(err) {
		return nil, err
	}
	return m, nil
}

// reloadLocked re-reads the persisted state so codes/devices issued by a
// separate admin process (hub admin issue-code) become visible.
func (m *PairingManager) reloadLocked() error {
	b, err := os.ReadFile(m.path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil
		}
		return err
	}
	return m.applyState(b)
}

func (m *PairingManager) applyState(b []byte) error {
	var state struct {
		Codes   map[string]codeRecord   `json:"codes"`
		Devices map[string]deviceRecord `json:"devices"`
	}
	if err := json.Unmarshal(b, &state); err != nil {
		return fmt.Errorf("parse pairing state: %w", err)
	}
	if state.Codes != nil {
		m.codes = state.Codes
	}
	if state.Devices != nil {
		m.devices = state.Devices
	}
	return nil
}

// IssueCode generates a fresh one-time decimal pairing code with TTL.
func (m *PairingManager) IssueCode() (string, error) {
	// Pick a random length in [CodeMinDigits, CodeMaxDigits].
	lenBytes := make([]byte, 1)
	if _, err := m.rand(lenBytes); err != nil {
		return "", err
	}
	digits := CodeMinDigits + int(lenBytes[0])%(CodeMaxDigits-CodeMinDigits+1)

	// Random decimal digits (rejection sampling to avoid modulo bias).
	b := make([]byte, digits)
	for i := 0; i < digits; {
		rb := make([]byte, 1)
		if _, err := m.rand(rb); err != nil {
			return "", err
		}
		if rb[0] < 250 { // 0..249 maps cleanly to 0..9
			b[i] = '0' + rb[0]%10
			i++
		}
	}
	code := string(b)

	m.mu.Lock()
	defer m.mu.Unlock()
	m.codes[code] = codeRecord{ExpiresAt: m.now().Add(CodeTTL)}
	if err := m.saveLocked(); err != nil {
		delete(m.codes, code)
		return "", err
	}
	return code, nil
}

// ConsumeCode validates a pairing code (single-use, expiry, rate limit).
// Rate limiting is keyed by BOTH the code value and the request source, so
// an attacker rotating through different wrong codes cannot bypass the
// limit (review blocker 3). source is typically the client IP.
func (m *PairingManager) ConsumeCode(source, code string) error {
	m.mu.Lock()
	defer m.mu.Unlock()

	// Re-read the persisted state first: the NAS Installer may have issued
	// a fresh pairing code through `hub admin issue-code` in a separate
	// process, and this server process must see it (Foundation §6 local
	// administration).
	_ = m.reloadLocked()

	now := m.now()
	// Per-source limit: an attacker rotating code values still hits the
	// source budget within the window.
	if source != "" {
		if rec, ok := m.attemptSource[source]; ok {
			if now.Sub(rec.WindowFrom) >= rateLimitWindow {
				delete(m.attemptSource, source) // window elapsed -> allow again
			} else if rec.Count >= maxPairAttempts {
				return errRateLimited
			}
		}
	}
	// Per-code limit: brute-forcing one code value is also bounded.
	if rec, ok := m.attempt[code]; ok {
		if now.Sub(rec.WindowFrom) >= rateLimitWindow {
			delete(m.attempt, code) // window elapsed -> allow again
		} else if rec.Count >= maxPairAttempts {
			return errRateLimited
		}
	}

	rec, ok := m.codes[code]
	if !ok {
		m.recordFailureLocked(code, source, now)
		_ = m.saveLocked()
		return errInvalidCode
	}
	if now.After(rec.ExpiresAt) {
		delete(m.codes, code)
		m.recordFailureLocked(code, source, now)
		_ = m.saveLocked()
		return errInvalidCode // expired
	}
	// Single use: consume now.
	delete(m.codes, code)
	delete(m.attempt, code)
	delete(m.attemptSource, source)
	return m.saveLocked()
}

// recordFailureLocked increments the rate-limit counters for code and
// source, starting a new window if the previous one has elapsed.
func (m *PairingManager) recordFailureLocked(code, source string, now time.Time) {
	rec, ok := m.attempt[code]
	if !ok || now.Sub(rec.WindowFrom) >= rateLimitWindow {
		rec = attemptRecord{Count: 1, WindowFrom: now}
	} else {
		rec.Count++
	}
	m.attempt[code] = rec

	if source != "" {
		srec, sok := m.attemptSource[source]
		if !sok || now.Sub(srec.WindowFrom) >= rateLimitWindow {
			srec = attemptRecord{Count: 1, WindowFrom: now}
		} else {
			srec.Count++
		}
		m.attemptSource[source] = srec
	}
}

// PairDevice creates a unique device record with a fresh opaque token.
// Returns the device_id and the plaintext device_token (returned only
// once, during successful pairing). Only a verifier is persisted.
func (m *PairingManager) PairDevice(name string) (deviceID, token string, err error) {
	if name == "" || len(name) > 64 {
		return "", "", errors.New("device_name must be 1-64 characters")
	}
	id, err := uuid.NewRandom()
	if err != nil {
		return "", "", err
	}
	tb := make([]byte, tokenBytes)
	if _, err := m.rand(tb); err != nil {
		return "", "", err
	}
	token = base64.RawURLEncoding.EncodeToString(tb)
	verifier := tokenVerifier(token)

	m.mu.Lock()
	defer m.mu.Unlock()
	// Re-load persisted devices before mutating so a concurrent admin
	// revocation is not lost when this process saves (review blocker:
	// cross-process state consistency).
	_ = m.reloadLocked()
	m.devices[id.String()] = deviceRecord{
		Name:      name,
		Verifier:  verifier,
		CreatedAt: m.now().UTC(),
	}
	if err := m.saveLocked(); err != nil {
		delete(m.devices, id.String())
		return "", "", err
	}
	return id.String(), token, nil
}

// TokenAuthFunc adapts a token-checking function so callers can plug the
// PairingManager into the auth middleware.
type TokenAuthFunc func(token string) bool

// AuthenticateToken implements the auth.TokenAuthenticator shape.
func (f TokenAuthFunc) AuthenticateToken(token string) bool { return f(token) }

// AuthenticateToken validates a presented device token against the stored
// verifier. Revoked devices fail authentication (contract §5/§6).
//
// The state is reloaded from disk on every authentication so that a
// revocation issued by a separate process (`hub admin revoke-device`,
// run via docker exec by the Installer) takes effect immediately on the
// running Hub server (review blocker: revocation must be immediate).
func (m *PairingManager) AuthenticateToken(token string) bool {
	if token == "" {
		return false
	}
	verifier := tokenVerifier(token)
	m.mu.Lock()
	defer m.mu.Unlock()
	_ = m.reloadLocked()
	for _, rec := range m.devices {
		if subtle.ConstantTimeCompare([]byte(rec.Verifier), []byte(verifier)) != 1 {
			continue
		}
		return !rec.Revoked
	}
	return false
}

// RevokeDevice revokes one device by id; subsequent auth fails (401).
func (m *PairingManager) RevokeDevice(deviceID string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	_ = m.reloadLocked()
	rec, ok := m.devices[deviceID]
	if !ok {
		return errors.New("device not found")
	}
	rec.Revoked = true
	m.devices[deviceID] = rec
	return m.saveLocked()
}

// Devices returns a non-secret snapshot of paired devices (contract §6:
// listing in non-secret form). Verifiers are never exposed.
func (m *PairingManager) Devices() []Device {
	m.mu.Lock()
	defer m.mu.Unlock()
	out := make([]Device, 0, len(m.devices))
	for id, rec := range m.devices {
		out = append(out, Device{
			ID:        id,
			Name:      rec.Name,
			CreatedAt: rec.CreatedAt,
			Revoked:   rec.Revoked,
		})
	}
	return out
}

// DeviceCount returns the number of paired devices.
func (m *PairingManager) DeviceCount() int {
	m.mu.Lock()
	defer m.mu.Unlock()
	return len(m.devices)
}

// tokenVerifier returns the non-reversible verifier of a device token.
func tokenVerifier(token string) string {
	sum := sha256.Sum256([]byte(token))
	return hex.EncodeToString(sum[:])
}

var (
	errInvalidCode = errors.New("invalid or expired pairing code")
	errRateLimited = errors.New("too many invalid pairing attempts; try again later")
)

func (m *PairingManager) saveLocked() error {
	if m.path == "" {
		return nil
	}
	if err := os.MkdirAll(filepath.Dir(m.path), 0o755); err != nil {
		return err
	}
	state := struct {
		Codes   map[string]codeRecord   `json:"codes"`
		Devices map[string]deviceRecord `json:"devices"`
	}{Codes: m.codes, Devices: m.devices}
	b, err := json.MarshalIndent(state, "", "  ")
	if err != nil {
		return err
	}
	tmp := m.path + ".tmp"
	if err := os.WriteFile(tmp, b, 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, m.path)
}
