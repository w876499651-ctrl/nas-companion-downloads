// Package discovery serves the frozen GET /api/v1/services contract.
package discovery

import (
	"encoding/json"
	"os"
)

// Service is the App-facing discovery item. Only id/installed/healthy are
// part of the V2 contract; routing metadata never reaches the App.
type Service struct {
	ID        string `json:"id"`
	Installed bool   `json:"installed"`
	Healthy   bool   `json:"healthy"`
}

// KnownServiceIDs is the frozen allow-list.
var KnownServiceIDs = map[string]bool{
	"qbittorrent": true,
	"jackett":     true,
	"cloudlink":   true,
	"anirss":      true,
	"xunlei":      true,
	"suwayomi":    true,
}

// ReadRegistry loads the installer's credential-free registry file and maps
// it to the App-facing discovery list. A missing file yields an empty list.
func ReadRegistry(path string) ([]Service, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return []Service{}, nil
		}
		return nil, err
	}
	var doc struct {
		Services []struct {
			ID        string `json:"id"`
			Installed bool   `json:"installed"`
			Healthy   bool   `json:"healthy"`
		} `json:"services"`
	}
	if err := json.Unmarshal(b, &doc); err != nil {
		return nil, err
	}
	out := []Service{}
	for _, s := range doc.Services {
		if !KnownServiceIDs[s.ID] {
			continue
		}
		out = append(out, Service{ID: s.ID, Installed: s.Installed, Healthy: s.Healthy})
	}
	return out, nil
}
