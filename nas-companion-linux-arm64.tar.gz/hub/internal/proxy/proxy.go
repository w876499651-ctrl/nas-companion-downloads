// Package proxy implements the V2 Hub allow-listed reverse proxy.
// It forwards only the six frozen service prefixes, strips Hub auth and
// hop-by-hop headers, and streams bodies without buffering large files.
package proxy

import (
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
)

// Proxy routes /proxy/{service}/* to the configured internal target.
type Proxy struct {
	// Targets maps frozen service ids to their internal base URL
	// (network alias + container port), e.g. http://qbittorrent:8080.
	Targets map[string]string

	// Client is the upstream transport; defaults to http.DefaultClient.
	Client *http.Client
}

// hopByHopHeaders must never be forwarded.
var hopByHopHeaders = []string{
	"Connection",
	"Keep-Alive",
	"Proxy-Authenticate",
	"Proxy-Authorization",
	"Te",
	"Trailer",
	"Transfer-Encoding",
	"Upgrade",
}

// ServeHTTP implements http.Handler.
func (p *Proxy) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	service, rest, ok := splitProxyPath(r.URL.Path)
	if !ok {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}
	base, ok := p.Targets[service]
	if !ok {
		http.Error(w, "unknown service", http.StatusNotFound)
		return
	}
	// Reject any request that smuggles a URL parameter: the proxy never
	// accepts an upstream URL from the caller.
	if hasURLParam(r) {
		http.Error(w, "arbitrary url rejected", http.StatusBadRequest)
		return
	}

	upstream := base + rest
	if r.URL.RawQuery != "" {
		upstream += "?" + r.URL.RawQuery
	}
	req, err := http.NewRequestWithContext(r.Context(), r.Method, upstream, r.Body)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadGateway)
		return
	}
	copyForwardHeaders(req.Header, r.Header)

	client := p.Client
	if client == nil {
		client = http.DefaultClient
	}
	resp, err := client.Do(req)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadGateway)
		return
	}
	defer resp.Body.Close()

	copyResponseHeaders(w.Header(), resp.Header)
	w.WriteHeader(resp.StatusCode)
	// Stream the body; large files/images are never buffered fully in memory.
	_, _ = io.Copy(w, resp.Body)
}

// splitProxyPath extracts the service id and the remaining upstream path
// from a /proxy/{service}/* request. It rejects anything else.
func splitProxyPath(path string) (service, rest string, ok bool) {
	const prefix = "/proxy/"
	if !strings.HasPrefix(path, prefix) {
		return "", "", false
	}
	trimmed := strings.TrimPrefix(path, prefix)
	idx := strings.IndexByte(trimmed, '/')
	if idx < 0 {
		// Allow /proxy/{service} (no trailing path) -> upstream "/".
		return trimmed, "/", true
	}
	return trimmed[:idx], trimmed[idx:], true
}

// hasURLParam rejects requests that attempt to smuggle an upstream URL.
func hasURLParam(r *http.Request) bool {
	q := r.URL.Query()
	if q.Has("url") || q.Has("upstream") || q.Has("target") || q.Has("host") {
		return true
	}
	if h := r.Header.Get("X-Upstream-Url"); h != "" {
		return true
	}
	return false
}

// copyForwardHeaders copies client headers, dropping the Hub auth header
// and hop-by-hop headers.
func copyForwardHeaders(dst, src http.Header) {
	for k, vv := range src {
		if strings.EqualFold(k, "Authorization") {
			continue // Hub auth must not reach upstream services.
		}
		if isHopByHop(k) {
			continue
		}
		for _, v := range vv {
			dst.Add(k, v)
		}
	}
}

// copyResponseHeaders copies upstream response headers, dropping
// hop-by-hop headers.
func copyResponseHeaders(dst, src http.Header) {
	for k, vv := range src {
		if isHopByHop(k) {
			continue
		}
		for _, v := range vv {
			dst.Add(k, v)
		}
	}
}

func isHopByHop(name string) bool {
	for _, h := range hopByHopHeaders {
		if strings.EqualFold(h, name) {
			return true
		}
	}
	return false
}

// NewTestServer returns a test HTTP server backing a proxy, for wiring.
func NewTestServer(handler http.Handler) *httptest.Server {
	return httptest.NewServer(handler)
}

var _ = fmt.Sprintf
