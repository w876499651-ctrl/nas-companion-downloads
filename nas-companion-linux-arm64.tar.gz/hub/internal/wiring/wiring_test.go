package wiring

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/nas-companion/nas/v2/hub/internal/pairing"
)

// TestHubEndToEnd verifies the full contract flow:
// identity challenge (unauthenticated, stable) -> one-time pairing ->
// per-device token auth -> services -> proxy, and revoke -> 401.
func TestHubEndToEnd(t *testing.T) {
	up := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("upstream-ok"))
	}))
	defer up.Close()

	dir := t.TempDir()
	regPath := filepath.Join(dir, "registry.json")
	regBody := `{"services":[
		{"id":"qbittorrent","installed":true,"healthy":true,"networkAlias":"qbittorrent","containerPort":8080,"hostPort":18080},
		{"id":"jackett","installed":false,"healthy":false,"networkAlias":"jackett","containerPort":9117,"hostPort":19117}
	]}`
	if err := os.WriteFile(regPath, []byte(regBody), 0o600); err != nil {
		t.Fatal(err)
	}

	pm, err := pairing.NewPairingManager(dir)
	if err != nil {
		t.Fatal(err)
	}
	handler := Build(Options{
		DataDir:        dir,
		RegistryPath:   regPath,
		ServiceTargets: map[string]string{"qbittorrent": up.URL, "jackett": up.URL},
		PairManager:    pm,
	})
	srv := httptest.NewServer(handler)
	defer srv.Close()

	// 1. Identity challenge is unauthenticated and stable across requests.
	fp := func() string {
		var body bytes.Buffer
		body.WriteString(`{"nonce":"AAAAAAAAAAAAAAAAAAAAAA"}`)
		resp, err := http.Post(srv.URL+"/api/v1/identity/challenge", "application/json", &body)
		if err != nil {
			t.Fatal(err)
		}
		defer resp.Body.Close()
		if resp.StatusCode != http.StatusOK {
			t.Fatalf("challenge status = %d", resp.StatusCode)
		}
		var out map[string]string
		if err := json.NewDecoder(resp.Body).Decode(&out); err != nil {
			t.Fatal(err)
		}
		if out["signature"] == "" || out["public_key"] == "" {
			t.Fatalf("challenge missing fields: %v", out)
		}
		return out["hub_id"]
	}
	fp1, fp2 := fp(), fp()
	if fp1 == "" || fp1 != fp2 {
		t.Fatalf("hub_id unstable: %q vs %q", fp1, fp2)
	}

	// 2. One-time pairing.
	code, err := pm.IssueCode()
	if err != nil {
		t.Fatal(err)
	}
	pairBody := `{"pairing_code":"` + code + `","device_name":"test-phone"}`
	pairResp, err := http.Post(srv.URL+"/api/v1/pair", "application/json", strings.NewReader(pairBody))
	if err != nil {
		t.Fatal(err)
	}
	var dev struct {
		HubID       string `json:"hub_id"`
		PublicKey   string `json:"public_key"`
		DeviceID    string `json:"device_id"`
		DeviceToken string `json:"device_token"`
	}
	if err := json.NewDecoder(pairResp.Body).Decode(&dev); err != nil {
		t.Fatal(err)
	}
	pairResp.Body.Close()
	if dev.DeviceID == "" || dev.DeviceToken == "" || dev.HubID == "" || dev.PublicKey == "" {
		t.Fatalf("pair response incomplete: %+v", dev)
	}
	if dev.HubID != fp1 {
		t.Fatalf("pair hub_id != challenge hub_id")
	}

	// 3. Unauthenticated services call -> 401.
	svcReq, _ := http.NewRequest(http.MethodGet, srv.URL+"/api/v1/services", nil)
	svcResp, _ := http.DefaultClient.Do(svcReq)
	svcResp.Body.Close()
	if svcResp.StatusCode != http.StatusUnauthorized {
		t.Fatalf("unauthenticated services status = %d", svcResp.StatusCode)
	}

	// 4. Authenticated services call -> 200 with frozen shape.
	authReq, _ := http.NewRequest(http.MethodGet, srv.URL+"/api/v1/services", nil)
	authReq.Header.Set("Authorization", "Bearer "+dev.DeviceToken)
	authResp, err := http.DefaultClient.Do(authReq)
	if err != nil {
		t.Fatal(err)
	}
	defer authResp.Body.Close()
	if authResp.StatusCode != http.StatusOK {
		t.Fatalf("authenticated services status = %d", authResp.StatusCode)
	}
	var sb strings.Builder
	buf := make([]byte, 1024)
	for {
		n, err := authResp.Body.Read(buf)
		sb.Write(buf[:n])
		if err != nil {
			break
		}
	}
	if !strings.Contains(sb.String(), `"id":"qbittorrent"`) || !strings.Contains(sb.String(), `"installed":true`) {
		t.Fatalf("services body malformed: %s", sb.String())
	}
	if strings.Contains(sb.String(), "hostPort") || strings.Contains(sb.String(), "containerPort") {
		t.Fatalf("services body leaks routing metadata: %s", sb.String())
	}

	// 5. Proxy forwards with device token, Hub Authorization not forwarded.
	proxyReq, _ := http.NewRequest(http.MethodGet, srv.URL+"/proxy/qbittorrent/api/status", nil)
	proxyReq.Header.Set("Authorization", "Bearer "+dev.DeviceToken)
	proxyResp, err := http.DefaultClient.Do(proxyReq)
	if err != nil {
		t.Fatal(err)
	}
	defer proxyResp.Body.Close()
	if proxyResp.StatusCode != http.StatusOK {
		t.Fatalf("proxy status = %d", proxyResp.StatusCode)
	}
	b2 := make([]byte, 64)
	n, _ := proxyResp.Body.Read(b2)
	if string(b2[:n]) != "upstream-ok" {
		t.Fatalf("proxy body = %q", string(b2[:n]))
	}

	// 6. Unknown service rejected.
	badReq, _ := http.NewRequest(http.MethodGet, srv.URL+"/proxy/evil/x", nil)
	badReq.Header.Set("Authorization", "Bearer "+dev.DeviceToken)
	badResp, _ := http.DefaultClient.Do(badReq)
	badResp.Body.Close()
	if badResp.StatusCode != http.StatusNotFound {
		t.Fatalf("unknown service status = %d", badResp.StatusCode)
	}

	// 7. Revoke the device -> immediate 401.
	if err := pm.RevokeDevice(dev.DeviceID); err != nil {
		t.Fatal(err)
	}
	revokedReq, _ := http.NewRequest(http.MethodGet, srv.URL+"/api/v1/services", nil)
	revokedReq.Header.Set("Authorization", "Bearer "+dev.DeviceToken)
	revokedResp, _ := http.DefaultClient.Do(revokedReq)
	revokedResp.Body.Close()
	if revokedResp.StatusCode != http.StatusUnauthorized {
		t.Fatalf("revoked device status = %d", revokedResp.StatusCode)
	}
}

// TestPairCodeReusedRejected verifies the pairing code is single-use over
// the wire (a second pair attempt with the same code must 401).
func TestPairCodeReusedRejected(t *testing.T) {
	dir := t.TempDir()
	pm, _ := pairing.NewPairingManager(dir)
	handler := Build(Options{DataDir: dir, RegistryPath: filepath.Join(dir, "registry.json"), PairManager: pm})
	srv := httptest.NewServer(handler)
	defer srv.Close()

	code, _ := pm.IssueCode()
	body := `{"pairing_code":"` + code + `","device_name":"phone"}`
	for i := 0; i < 2; i++ {
		resp, err := http.Post(srv.URL+"/api/v1/pair", "application/json", strings.NewReader(body))
		if err != nil {
			t.Fatal(err)
		}
		resp.Body.Close()
		if i == 0 && resp.StatusCode != http.StatusOK {
			t.Fatalf("first pair status = %d", resp.StatusCode)
		}
		if i == 1 && resp.StatusCode != http.StatusUnauthorized {
			t.Fatalf("reused code status = %d", resp.StatusCode)
		}
	}
}

// TestPairInvalidCodeRejected verifies a bad code fails pairing.
func TestPairInvalidCodeRejected(t *testing.T) {
	dir := t.TempDir()
	pm, _ := pairing.NewPairingManager(dir)
	handler := Build(Options{DataDir: dir, RegistryPath: filepath.Join(dir, "registry.json"), PairManager: pm})
	srv := httptest.NewServer(handler)
	defer srv.Close()

	body := `{"pairing_code":"123456","device_name":"phone"}`
	resp, err := http.Post(srv.URL+"/api/v1/pair", "application/json", strings.NewReader(body))
	if err != nil {
		t.Fatal(err)
	}
	resp.Body.Close()
	if resp.StatusCode != http.StatusUnauthorized {
		t.Fatalf("invalid code status = %d", resp.StatusCode)
	}
}
