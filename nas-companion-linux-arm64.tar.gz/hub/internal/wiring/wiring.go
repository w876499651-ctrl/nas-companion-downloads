package wiring

import (
	"encoding/json"
	"net/http"

	"github.com/nas-companion/nas/v2/hub/internal/auth"
	"github.com/nas-companion/nas/v2/hub/internal/discovery"
	"github.com/nas-companion/nas/v2/hub/internal/identity"
	"github.com/nas-companion/nas/v2/hub/internal/pairing"
	"github.com/nas-companion/nas/v2/hub/internal/proxy"
)

// Options configures the Hub router.
type Options struct {
	// DataDir is where Hub identity, pairing state and devices persist.
	// The identity is stable across restarts and address changes.
	DataDir string
	// RegistryPath points to the installer's credential-free registry file.
	RegistryPath string
	// ServiceTargets maps frozen service ids to internal base URLs
	// (network alias + container port).
	ServiceTargets map[string]string
	// PairManager optionally overrides the pairing manager (tests use a
	// shared instance; production leaves nil and Build creates one in DataDir).
	PairManager *pairing.PairingManager
}

// Build returns the fully wired http.Handler implementing the frozen
// contracts/v2/hub-access.md endpoints.
func Build(opts Options) http.Handler {
	id, err := identity.LoadOrCreate(opts.DataDir + "/hub-identity.pem")
	if err != nil {
		panic("hub identity: " + err.Error())
	}
	pm := opts.PairManager
	if pm == nil {
		var err error
		pm, err = pairing.NewPairingManager(opts.DataDir)
		if err != nil {
			panic("hub pairing state: " + err.Error())
		}
	}

	mux := http.NewServeMux()

	// Public: identity proof (unauthenticated, before sending credentials).
	mux.Handle("/api/v1/identity/challenge", identity.ChallengeHandler(id))

	// Public: one-time pairing -> per-device credential.
	mux.Handle("/api/v1/pair", PairHandler(pm, id))

	// Device-authenticated area.
	authMW := auth.RequireDevice(pairing.TokenAuthFunc(pm.AuthenticateToken))

	// GET /api/v1/services from the credential-free registry.
	mux.Handle("/api/v1/services", authMW(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			w.WriteHeader(http.StatusMethodNotAllowed)
			return
		}
		svcs, err := discovery.ReadRegistry(opts.RegistryPath)
		if err != nil {
			w.WriteHeader(http.StatusInternalServerError)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]any{"services": svcs})
	})))

	// Allow-list reverse proxy (device auth, Authorization never forwarded).
	mux.Handle("/proxy/", authMW(&proxy.Proxy{Targets: opts.ServiceTargets}))

	return mux
}

// DefaultTargets returns the internal targets for the six frozen services.
// Values use network alias + container port (never host ports).
func DefaultTargets() map[string]string {
	return map[string]string{
		"qbittorrent": "http://qbittorrent:8080",
		"jackett":     "http://jackett:9117",
		"cloudlink":   "http://cloudlink:80",
		"anirss":      "http://anirss:7789",
		"xunlei":      "http://xunlei:2345",
		"suwayomi":    "http://suwayomi:4567",
	}
}
