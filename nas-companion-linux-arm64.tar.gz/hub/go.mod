module github.com/nas-companion/nas/v2/hub

go 1.23.0

require github.com/google/uuid v1.6.0
